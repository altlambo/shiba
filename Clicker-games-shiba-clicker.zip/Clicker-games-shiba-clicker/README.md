🐶 This is the code for https://shiba-clicker.tk/ a simple clicker game 🐶
